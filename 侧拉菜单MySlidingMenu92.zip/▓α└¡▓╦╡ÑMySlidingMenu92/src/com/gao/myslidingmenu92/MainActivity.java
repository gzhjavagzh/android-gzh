package com.gao.myslidingmenu92;

import com.gao.myslidingmenu92.view.MySlidingMenuView;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.Window;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

	private Button menu;
	private MySlidingMenuView slidmeu;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// ȥ��������
		getWindow().requestFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.activity_main);
		initView();
	}

	/**
	 * ��ʼ���ؼ� 2016-9-4 ����5:34:04
	 */
	private void initView() {
		menu = (Button) findViewById(R.id.menu);
		slidmeu = (MySlidingMenuView) findViewById(R.id.myslidingmenu);
		
		//���ӵ���¼�
		menu.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				slidmeu.toggle();
			}
		});
	}

	/**
	 * ����˵���Ŀ���¼� 2016-9-4 ����12:35:32
	 */
	public void showText(View v) {
		TextView textView = (TextView) v;
		Toast.makeText(this, textView.getText(), 0).show();
	}

}
